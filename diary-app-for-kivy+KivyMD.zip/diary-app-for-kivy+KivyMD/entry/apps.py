from django.apps import AppConfig


class EntryConfig(AppConfig):
    name = 'entry'
